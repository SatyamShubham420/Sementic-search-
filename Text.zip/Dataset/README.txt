DATASET EXPLANATION
-------------------

This dataset is the Complete Works of Arthur Conan Doyle on the topic of Sherlock Holmes.

It is a collection of 56 short stories and 4 novels. The short stories are collected under 5 different anthologies:
- The Adventures of Sherlock Holmes
- The Memoirs of Sherlock Holmes
- The Return of Sherlock Holmes
- The Case-Book of Sherlock Holmes
- His Last Bow

The novels are:
- A Study in Scarlet
- The Sign of the Four
- The Hound of the Baskervilles
- The Adventures of Sherlock Holmes

Each story is in a separate file, and the files are named after the story.

TASK DESCRIPTION
----------------
1. Build a simple search engine that can search for stories by keyword. It should return the story name and the location of search keywords in the story.
- simple keyword search
- keyword search with OR and AND operators
- phrase search

2. Build a semantic search engine that can search for stories even without using exact keywords.